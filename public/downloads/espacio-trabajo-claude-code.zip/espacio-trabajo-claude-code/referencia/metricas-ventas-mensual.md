---
name: reference-metricas-mes
description: Dónde se guardan las métricas de ventas mensuales (ejemplo ilustrativo)
---

Las métricas de ventas del mes (facturación, ticket promedio, producto más vendido) se cargan en una planilla compartida, actualizada todos los lunes con los datos de la semana anterior.

Este tipo de memoria apunta a DÓNDE vive el dato, para no tener que preguntar cada vez ni duplicar la planilla en otro lado.
