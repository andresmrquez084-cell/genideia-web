---
name: reference-proveedores
description: Contactos y condiciones de los proveedores actuales (ejemplo ilustrativo)
---

Los contactos de proveedores (mayorista de tela, taller de costura, imprenta de etiquetas) y sus condiciones de pago están en un documento único, no dispersos en chats de WhatsApp viejos.

Sirve para no perder tiempo buscando "¿con quién hablaba de esto?" cada vez que hay que hacer un pedido nuevo.
