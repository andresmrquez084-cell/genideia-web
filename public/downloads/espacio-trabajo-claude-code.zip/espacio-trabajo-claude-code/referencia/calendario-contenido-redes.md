---
name: reference-calendario-contenido
description: Dónde vive el calendario de contenido de redes (ejemplo ilustrativo)
---

El calendario de publicaciones (qué sale, cuándo, en qué formato) vive en un tablero compartido con el equipo de redes, no en la cabeza de una sola persona.

Este tipo de memoria evita que se pierda contexto cuando cambia quién está a cargo de las redes.
