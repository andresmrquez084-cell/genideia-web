---
name: reference-ejemplo
description: Dónde viven las fotos de producto antes de subir algo nuevo a la web (ejemplo ilustrativo)
---

Las fotos de producto (ya editadas, fondo blanco) se suben primero a una carpeta compartida de Drive, antes de subir cualquier producto nuevo a la tienda online.

Este es el tipo de memoria que apunta a DÓNDE está la información, no la información en sí — útil para no tener que preguntar "¿dónde estaba esto?" cada vez.
