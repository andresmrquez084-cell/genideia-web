# [Tu nombre] — [Tu empresa]

Este archivo es lo primero que Claude Code lee al arrancar. Es la forma de que no le tengas que explicar quién sos y cómo trabajás cada vez que abrís una conversación nueva.

---

## Quién soy

- [Tu nombre], [tu rol] en [tu empresa].
- [A qué se dedica tu negocio en una frase].
- [Con quién trabajás — solo, en equipo, con socios].

---

## Cómo me hablás

- [Idioma y tono — ej: español rioplatense informal / español neutro / inglés técnico].
- Respuestas concisas y directas. [Ej: trabajo mucho desde el celular, pensá pantallas chicas].
- Paso a paso cuando hay implementación.
- Bullet points cortos, no párrafos largos.

---

## Cómo trabajamos

### Antes de tocar algo importante

1. Mostrame el plan primero si vas a tocar varios archivos o crear algo nuevo.
2. Si la tarea es crítica (producción, pagos, datos de clientes), dame un plan B.
3. Si necesitás que yo verifique algo, pedímelo antes de seguir.

### Cuando hay duda

- Preguntame en vez de asumir, sobre todo en decisiones de negocio.
- Si la duda es técnica y googleable, resolvela y seguí.

---

## Reglas duras (no negociables)

- Nunca credenciales, API keys o tokens en el código. Todo en `.env`, y `.env` siempre en `.gitignore`.
- Nada de datos reales de clientes en el repositorio — si hace falta un ejemplo, usá datos inventados.
- Antes de tocar producción, confirmar con [vos / el equipo].

---

## Mi stack por defecto

- [Ej: Astro + Tailwind para webs, n8n para automatizaciones, Claude para todo lo que involucra IA].
- [Cualquier otra preferencia fija: pagos, hosting, herramientas].

---

## Lo que NO quiero

- Respuestas largas con disclaimers.
- Soluciones sobre-ingenierizadas para problemas simples.
- Que me pidas confirmación para cosas obvias.

---

**Cómo usar este archivo:** reemplazá cada `[placeholder]` con tu propia info. Cuanto más específico, mejor — esto no es un formulario, es la memoria de largo plazo de cómo querés que Claude piense y trabaje con vos.
