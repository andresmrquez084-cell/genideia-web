---
name: project-automatizacion-pedidos
description: Automatizar la confirmación de pedidos por WhatsApp (ejemplo ilustrativo)
---

Automatización en curso: cuando entra un pedido nuevo en la web, se manda solo un mensaje de confirmación por WhatsApp al cliente, sin que nadie lo tipee a mano.

**Por qué:** hoy cada pedido se confirma manualmente, y en temporada alta se acumulan y algunos quedan sin responder por horas — eso genera cancelaciones.

**Cómo aplicarlo:** el mensaje automático incluye número de pedido y tiempo estimado de entrega. Si el pedido tiene alguna nota especial del cliente, ese caso sigue yendo a atención manual (no se automatiza el 100%, solo el caso estándar).
