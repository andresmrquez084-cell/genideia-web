---
name: project-ejemplo
description: Migración del catálogo viejo (Excel) a la tienda online nueva (ejemplo ilustrativo)
---

Traspaso del catálogo de productos desde una planilla Excel (la fuente actual, desordenada, con productos discontinuados mezclados) hacia la tienda online nueva.

**Por qué:** la planilla vieja es la única fuente de verdad hoy, pero tiene errores de precio y productos que ya no se venden — no se puede migrar tal cual, hay que limpiarla primero.

**Cómo aplicarlo:** antes de subir cualquier producto nuevo a la web, confirmar que está en la planilla limpia (no en la vieja). Fecha límite acordada: fin de mes. Quien depende de esto: el diseño de la tienda ya está listo, solo falta el contenido real.

Este es el tipo de memoria que guarda el ESTADO de un trabajo en curso — para que la próxima conversación arranque donde quedó, no desde cero.
