---
name: project-campana-verano
description: Campaña de temporada verano — fechas, presupuesto y piezas pendientes (ejemplo ilustrativo)
---

Campaña de la colección verano: arranca la primera semana del mes, presupuesto de pauta definido, 6 piezas de contenido (3 posteos + 3 historias) más un descuento de lanzamiento por 72hs.

**Por qué:** es la temporada de mayor venta del año para este rubro — todo lo demás se prioriza después de esto.

**Cómo aplicarlo:** las piezas se programan con una semana de anticipación, no el mismo día. El descuento de lanzamiento no se repite en otra campaña del año (pierde exclusividad).
