---
name: project-prospeccion-mayoristas
description: Búsqueda de nuevos proveedores mayoristas para bajar costo de producto (ejemplo ilustrativo)
---

Se está evaluando reemplazar al proveedor mayorista actual por uno con mejor precio por volumen, sin bajar la calidad de tela.

**Por qué:** el margen viene cayendo hace 2 temporadas por aumentos del proveedor actual, que no se pueden trasladar todos al precio final sin perder competitividad.

**Cómo aplicarlo:** cualquier proveedor nuevo se evalúa primero con un pedido chico de prueba antes de mover el volumen grande — nunca cambiar de proveedor principal sin haber probado calidad real.
