# Tu espacio de trabajo de Claude Code

Esta carpeta es un punto de partida real, no un tutorial. Bajala, abrila en Claude Code, y ya tenés funcionando lo mismo que viste en el video.

## Qué hay acá adentro

- **`CLAUDE.md`** — le enseña a Claude quién sos y cómo querés que te hable. Reemplazá los `[placeholder]` por tu propia info.
- **`.claude/skills/`** — cinco capacidades ya armadas y listas para usar:
  - `landing-page-pro` — arma una landing de ventas completa (copy + diseño) desde cero.
  - `automation-forge` — diseña automatizaciones reales (n8n, Make, Zapier) para eliminar trabajo manual.
  - `whatsapp-baileys` — integra un bot de WhatsApp en una app.
  - `mvp-blueprint` — convierte una idea en un MVP lanzable en 7 días.
  - `saas-starter-kit` — arma un SaaS completo (login, pagos con Stripe, base de datos) listo para desplegar.
- **`contexto/`** — quién es el negocio y sus reglas fijas de comportamiento.
- **`planes/`** — iniciativas en curso, una por archivo.
- **`referencia/`** — dónde vive cada cosa (fotos, métricas, contactos).
- **`INDICE.md`** — mapa de las tres carpetas de arriba.

Todo el contenido de `contexto/`, `planes/` y `referencia/` es un ejemplo inventado (un local de indumentaria ficticio) — es la plantilla, no el contenido. Reemplazalo por el tuyo.

## Cómo empezar

1. Instalá Claude Code (si todavía no lo tenés).
2. Abrí esta carpeta como tu espacio de trabajo.
3. Editá `CLAUDE.md` con tu info real.
4. Pedile directamente: *"armame una landing para [tu producto]"* o *"ayudame a automatizar [tu proceso repetitivo]"* — las skills se activan solas.

Cualquier duda, escribime.
