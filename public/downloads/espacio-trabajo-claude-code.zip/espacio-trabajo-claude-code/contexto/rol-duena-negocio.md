---
name: user-ejemplo
description: Rol, negocio y nivel técnico de quien usa este espacio de trabajo (ejemplo ilustrativo, no un cliente real)
---

Dueña de un local de indumentaria con un e-commerce chico (menos de 50 productos). No es técnica — nunca tocó código ni una terminal antes de esto. Prefiere que las explicaciones sean simples, sin jerga de programación, y que se le muestre el resultado (una web, un archivo) antes que el "cómo se hizo por dentro".

Este tipo de memoria sirve para que Claude adapte SU nivel de explicación a quién tiene enfrente — no es lo mismo explicarle un cambio a alguien que programa hace 10 años que a alguien que recién está empezando.
