---
name: feedback-tono-redes
description: El tono en redes es cercano, nunca de venta directa (ejemplo ilustrativo)
---

En las publicaciones de Instagram, el tono es cercano y conversacional — nunca "comprá ya" ni lenguaje de venta directa.

**Por qué:** una publicación armada como catálogo de oferta tuvo la mitad de interacción que las que cuentan una historia o muestran el producto puesto.

**Cómo aplicarlo:** el precio y el CTA de compra van en la bio o en los destacados, no en el pie de foto. El pie de foto cuenta algo (una anécdota, un uso del producto), nunca solo el precio.
