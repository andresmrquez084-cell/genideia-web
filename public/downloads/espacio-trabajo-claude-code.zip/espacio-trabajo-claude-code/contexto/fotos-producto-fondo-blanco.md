---
name: feedback-fotos-producto
description: Fondo blanco siempre, nunca repetir la misma foto entre publicaciones (ejemplo ilustrativo)
---

Todas las fotos de producto que se publican van con fondo blanco liso, nunca fondo de local o maniquí sin editar.

**Por qué:** las primeras publicaciones mezclaban fotos con distintos fondos y se veía desprolijo — rompía la identidad del feed.

**Cómo aplicarlo:** antes de programar cualquier publicación, chequear que la foto ya pasó por edición (fondo blanco) y que no se usó antes en otro posteo — llevar registro de qué foto se usó dónde.
