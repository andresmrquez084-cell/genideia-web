---
name: feedback-ejemplo
description: No prometer fecha de entrega sin confirmar stock primero (ejemplo ilustrativo)
---

Nunca confirmar una fecha de envío a un cliente sin chequear antes el stock real disponible.

**Por qué:** en un caso real se le dijo a un cliente "lo tenés el viernes" sin mirar el inventario, y ese producto ya no tenía stock — hubo que llamarlo a pedir disculpas y la venta casi se cae.

**Cómo aplicarlo:** antes de escribir cualquier fecha o compromiso de entrega, primero se verifica el stock (o se pregunta si no está a la vista), después se confirma la fecha.

Este es el tipo de memoria que evita repetir el mismo error dos veces — la próxima vez que Claude arme una respuesta a un cliente, ya sabe que tiene que chequear esto primero, sin que se lo tengas que recordar.
