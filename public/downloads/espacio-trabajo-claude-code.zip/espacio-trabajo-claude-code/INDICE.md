# Índice de contexto

## contexto/ — quién es el negocio y sus reglas de comportamiento
- [Rol y nivel técnico de la dueña](contexto/rol-duena-negocio.md)
- [Confirmar stock antes de prometer fecha de entrega](contexto/confirmar-stock-antes-fecha.md)
- [Tono en redes: cercano, nunca venta directa](contexto/tono-redes-cercano.md)
- [Fotos de producto: siempre fondo blanco](contexto/fotos-producto-fondo-blanco.md)

## planes/ — iniciativas en curso
- [Migración de catálogo a la web nueva](planes/migracion-catalogo-web-2026-03.md)
- [Campaña de temporada verano](planes/campana-verano-2026-01.md)
- [Automatizar confirmación de pedidos por WhatsApp](planes/automatizacion-confirmacion-pedidos-2026-02.md)
- [Prospección de nuevos proveedores mayoristas](planes/prospeccion-proveedores-mayoristas-2026-02.md)

## referencia/ — dónde vive cada cosa
- [Fotos de producto (Drive)](referencia/fotos-producto-drive.md)
- [Métricas de ventas del mes](referencia/metricas-ventas-mensual.md)
- [Contactos de proveedores](referencia/contactos-proveedores.md)
- [Calendario de contenido de redes](referencia/calendario-contenido-redes.md)
