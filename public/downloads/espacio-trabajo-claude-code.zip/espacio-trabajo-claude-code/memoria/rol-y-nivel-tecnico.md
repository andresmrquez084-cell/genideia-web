---
name: rol-y-nivel-tecnico
description: Rol y nivel técnico de quien usa este espacio (ejemplo ilustrativo, no un cliente real)
metadata:
  type: user
---

Dueña de un local de indumentaria con e-commerce chico. No es técnica: nunca usó una terminal.
Explicar sin jerga y mostrar el resultado (una web, un archivo) antes que el cómo por dentro.
