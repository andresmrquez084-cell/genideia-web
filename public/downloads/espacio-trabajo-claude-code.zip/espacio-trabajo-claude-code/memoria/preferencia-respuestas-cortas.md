---
name: preferencia-respuestas-cortas
description: Respuestas cortas y directas, sin disclaimers repetidos (ejemplo ilustrativo)
metadata:
  type: feedback
---

Respuestas directas, en bullets cortos.

**Why:** lee desde el celular y se cansa con párrafos largos.

**How to apply:** si la respuesta entra en 3 líneas, no la hagas de 30.
