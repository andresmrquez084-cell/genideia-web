---
name: fotos-producto-fondo-blanco
description: Las fotos de producto siempre van sobre fondo blanco (ejemplo ilustrativo)
metadata:
  type: reference
---

Fotos de producto para la web y redes: fondo blanco liso.
