# memoria/ — lo que Claude recuerda entre conversaciones

Claude Code lee `MEMORY.md` al arrancar. Cada línea de ese índice apunta a un archivo con una sola idea.

Tres tipos de memoria (campo `metadata.type` en el frontmatter):

- `user` — quién sos y cómo trabajás.
- `feedback` — cómo querés que Claude trabaje (corrección o confirmación). Incluí **Why** y **How to apply**.
- `reference` — dónde vive algo fuera del espacio (links, carpetas, cuentas).

Regla: antes de guardar algo nuevo, revisá si ya existe un archivo que lo cubra y actualizalo. Borrá lo que quedó mal.
